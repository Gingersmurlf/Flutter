# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\theo\\Downloads\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\webudvikler_hovedforløb\\flutter\\flutter_application_1" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\theo\\Downloads\\flutter"
  "PROJECT_DIR=C:\\webudvikler_hovedforløb\\flutter\\flutter_application_1"
  "FLUTTER_ROOT=C:\\Users\\theo\\Downloads\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\webudvikler_hovedforløb\\flutter\\flutter_application_1\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\webudvikler_hovedforløb\\flutter\\flutter_application_1"
  "FLUTTER_TARGET=C:\\webudvikler_hovedforløb\\flutter\\flutter_application_1\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDEuOQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049MDBiMGM5MWYwNg==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049NDJkM2Q3NWE1Ng==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMS41"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\webudvikler_hovedforløb\\flutter\\flutter_application_1\\.dart_tool\\package_config.json"
)
